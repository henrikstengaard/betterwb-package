To comply with the licenses of many software packages included in BetterWB, 
I had to include the full archive of many of those (they are in the LICENSES 
directory). They wont be installed in your system and are of no practical 
use to you. They are there, so that I dont get in legal troubles :) 